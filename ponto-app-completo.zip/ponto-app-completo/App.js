import React, { Suspense } from 'react';
import { ActivityIndicator, StatusBar, View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { SQLiteProvider } from 'expo-sqlite';
import { Ionicons } from '@expo/vector-icons';

import { initDb } from './src/database/db';
import { PontoProvider } from './src/context/PontoContext';
import RegistrarScreen from './src/screens/RegistrarScreen';
import HistoricoScreen from './src/screens/HistoricoScreen';
import ResumoScreen from './src/screens/ResumoScreen';
import { cores } from './src/theme';

const Tab = createBottomTabNavigator();

const ICONES = {
  Registrar: 'time-outline',
  Histórico: 'calendar-outline',
  Resumo: 'bar-chart-outline',
};

const Carregando = () => (
  <View style={{ flex: 1, justifyContent: 'center', backgroundColor: cores.fundo }}>
    <ActivityIndicator size="large" color={cores.primaria} />
  </View>
);

export default function App() {
  return (
    <SafeAreaProvider>
      <StatusBar barStyle="light-content" backgroundColor={cores.primaria} />
      <Suspense fallback={<Carregando />}>
        <SQLiteProvider databaseName="ponto.db" onInit={initDb} useSuspense>
          <PontoProvider>
            <NavigationContainer>
              <Tab.Navigator
                screenOptions={({ route }) => ({
                  headerStyle: { backgroundColor: cores.primaria },
                  headerTintColor: cores.branco,
                  tabBarActiveTintColor: cores.destaque,
                  tabBarInactiveTintColor: cores.suave,
                  tabBarIcon: ({ color, size }) => (
                    <Ionicons name={ICONES[route.name]} size={size} color={color} />
                  ),
                })}
              >
                <Tab.Screen name="Registrar" component={RegistrarScreen} />
                <Tab.Screen name="Histórico" component={HistoricoScreen} />
                <Tab.Screen name="Resumo" component={ResumoScreen} />
              </Tab.Navigator>
            </NavigationContainer>
          </PontoProvider>
        </SQLiteProvider>
      </Suspense>
    </SafeAreaProvider>
  );
}
