import React from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { usePonto } from '../context/PontoContext';
import { cores } from '../theme';
import {
  JORNADA_MS,
  calcularTrabalhado,
  chaveDia,
  formatarDuracao,
  formatarSaldo,
  inicioSemana,
} from '../utils/tempo';

const NOMES = ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'];

export default function ResumoScreen() {
  const { registros, agora } = usePonto();
  const hoje = chaveDia(agora);
  const inicio = inicioSemana(agora);

  const dias = NOMES.map((nome, i) => {
    const d = new Date(inicio);
    d.setDate(inicio.getDate() + i);
    const chave = chaveDia(d);
    const regs = registros.filter((r) => r.dia === chave);
    return {
      nome,
      chave,
      util: i < 5,
      passou: chave <= hoje,
      ms: calcularTrabalhado(regs, agora, chave === hoje),
    };
  });

  const total = dias.reduce((s, d) => s + d.ms, 0);
  const esperado = dias.filter((d) => d.util && d.passou).length * JORNADA_MS;
  const saldo = total - esperado;

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ paddingVertical: 16 }}>
      <View style={styles.resumo}>
        <View style={styles.bloco}>
          <Text style={styles.rotulo}>Total da semana</Text>
          <Text style={styles.valor}>{formatarDuracao(total)}</Text>
        </View>
        <View style={styles.bloco}>
          <Text style={styles.rotulo}>Saldo</Text>
          <Text style={[styles.valor, { color: saldo < 0 ? '#ff8f8f' : '#7ee0d3' }]}>
            {formatarSaldo(saldo)}
          </Text>
        </View>
      </View>

      <Text style={styles.titulo}>Horas por dia</Text>
      <View style={styles.card}>
        {dias.map((d) => (
          <View key={d.chave} style={styles.linha}>
            <Text style={[styles.dia, d.chave === hoje && styles.diaHoje]}>{d.nome}</Text>
            <View style={styles.trilho}>
              <View
                style={[
                  styles.barra,
                  { width: `${Math.min(100, (d.ms / JORNADA_MS) * 100)}%` },
                  d.ms >= JORNADA_MS && { backgroundColor: cores.positivo },
                ]}
              />
            </View>
            <Text style={styles.horas}>{formatarDuracao(d.ms)}</Text>
          </View>
        ))}
      </View>
      <Text style={styles.nota}>
        Jornada considerada: 8h por dia útil (segunda a sexta). O saldo conta só os dias úteis
        até hoje.
      </Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: cores.fundo, paddingHorizontal: 20 },
  resumo: {
    flexDirection: 'row',
    backgroundColor: cores.primaria,
    borderRadius: 20,
    padding: 20,
  },
  bloco: { flex: 1, alignItems: 'center' },
  rotulo: { color: '#c9d1e3', fontSize: 13 },
  valor: { color: cores.branco, fontSize: 28, fontWeight: '700', marginTop: 4 },
  titulo: { fontSize: 18, fontWeight: '700', color: cores.primaria, marginTop: 24, marginBottom: 8 },
  card: { backgroundColor: cores.branco, borderRadius: 14, padding: 14 },
  linha: { flexDirection: 'row', alignItems: 'center', paddingVertical: 8 },
  dia: { width: 40, fontSize: 14, color: cores.texto },
  diaHoje: { fontWeight: '800', color: cores.primaria },
  trilho: {
    flex: 1,
    height: 10,
    backgroundColor: '#e8eaf2',
    borderRadius: 5,
    marginHorizontal: 10,
    overflow: 'hidden',
  },
  barra: { height: '100%', backgroundColor: cores.destaque, borderRadius: 5 },
  horas: {
    width: 56,
    textAlign: 'right',
    fontSize: 14,
    fontWeight: '600',
    color: cores.primaria,
    fontVariant: ['tabular-nums'],
  },
  nota: { color: cores.suave, fontSize: 12, marginTop: 12 },
});
