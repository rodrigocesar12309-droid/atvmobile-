import React, { useMemo } from 'react';
import { Alert, FlatList, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { usePonto } from '../context/PontoContext';
import { cores } from '../theme';
import {
  JORNADA_MS,
  calcularTrabalhado,
  chaveDia,
  formatarDiaChave,
  formatarDuracao,
  formatarHora,
  formatarSaldo,
} from '../utils/tempo';

export default function HistoricoScreen() {
  const { registros, agora, excluirRegistro, limparTudo } = usePonto();
  const hoje = chaveDia(agora);

  const dias = useMemo(() => {
    const grupos = {};
    registros.forEach((r) => (grupos[r.dia] = [...(grupos[r.dia] || []), r]));
    return Object.keys(grupos)
      .sort((a, b) => (a < b ? 1 : -1))
      .map((dia) => ({
        dia,
        itens: grupos[dia].sort((a, b) => a.timestamp - b.timestamp),
      }));
  }, [registros]);

  const confirmarExclusao = (id) =>
    Alert.alert('Excluir registro', 'Deseja remover esta batida?', [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Excluir', style: 'destructive', onPress: () => excluirRegistro(id) },
    ]);

  const confirmarLimpeza = () =>
    Alert.alert('Limpar histórico', 'Todos os registros serão apagados.', [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Apagar tudo', style: 'destructive', onPress: limparTudo },
    ]);

  const renderDia = ({ item }) => {
    const ehHoje = item.dia === hoje;
    const total = calcularTrabalhado(item.itens, agora, ehHoje);
    const saldo = total - JORNADA_MS;
    return (
      <View style={styles.card}>
        <View style={styles.cabecalho}>
          <Text style={styles.dia}>
            {formatarDiaChave(item.dia)}
            {ehHoje ? ' (hoje)' : ''}
          </Text>
          <View style={{ alignItems: 'flex-end' }}>
            <Text style={styles.total}>{formatarDuracao(total)}</Text>
            {!ehHoje && (
              <Text style={[styles.saldo, { color: saldo < 0 ? cores.perigo : cores.positivo }]}>
                {formatarSaldo(saldo)}
              </Text>
            )}
          </View>
        </View>
        {item.itens.map((r) => (
          <TouchableOpacity
            key={r.id}
            style={styles.linha}
            onLongPress={() => confirmarExclusao(r.id)}
          >
            <Text style={styles.tipo}>{r.tipo}</Text>
            <Text style={styles.hora}>{formatarHora(new Date(r.timestamp))}</Text>
          </TouchableOpacity>
        ))}
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <FlatList
        data={dias}
        keyExtractor={(i) => i.dia}
        renderItem={renderDia}
        contentContainerStyle={{ paddingVertical: 16 }}
        ListEmptyComponent={<Text style={styles.vazio}>Nenhum ponto registrado ainda.</Text>}
        ListFooterComponent={
          dias.length > 0 && (
            <View style={{ alignItems: 'center', gap: 12 }}>
              <Text style={styles.dica}>Segure uma batida para excluí-la.</Text>
              <TouchableOpacity onPress={confirmarLimpeza}>
                <Text style={styles.limpar}>Limpar histórico</Text>
              </TouchableOpacity>
            </View>
          )
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: cores.fundo, paddingHorizontal: 20 },
  card: { backgroundColor: cores.branco, borderRadius: 14, padding: 14, marginBottom: 12 },
  cabecalho: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 },
  dia: { fontSize: 16, fontWeight: '700', color: cores.primaria },
  total: { fontSize: 15, fontWeight: '700', color: cores.primaria },
  saldo: { fontSize: 12, fontWeight: '600' },
  linha: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 8,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: cores.borda,
  },
  tipo: { fontSize: 15, color: cores.texto },
  hora: { fontSize: 15, fontWeight: '600', color: cores.primaria, fontVariant: ['tabular-nums'] },
  vazio: { textAlign: 'center', color: cores.suave, marginTop: 40 },
  dica: { color: cores.suave, fontSize: 12 },
  limpar: { color: cores.perigo, fontSize: 14 },
});
