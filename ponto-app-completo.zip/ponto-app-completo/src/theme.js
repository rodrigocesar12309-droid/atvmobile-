export const cores = {
  fundo: '#f5f6fa',
  primaria: '#14213d',
  destaque: '#fca311',
  texto: '#3d4663',
  suave: '#6b7a99',
  borda: '#d9dce6',
  positivo: '#2a9d8f',
  perigo: '#c0392b',
  branco: '#ffffff',
};
