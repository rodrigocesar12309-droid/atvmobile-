export const TIPOS = ['Entrada', 'Saída para almoço', 'Volta do almoço', 'Saída'];
export const JORNADA_MS = 8 * 60 * 60 * 1000; // jornada diária de 8h

export const pad = (n) => String(n).padStart(2, '0');

export const chaveDia = (d) =>
  `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

export const formatarHora = (d, comSegundos = false) =>
  `${pad(d.getHours())}:${pad(d.getMinutes())}` +
  (comSegundos ? `:${pad(d.getSeconds())}` : '');

export const formatarDataLonga = (d) =>
  d.toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: 'long' });

export const formatarDiaChave = (chave) => {
  const [a, m, d] = chave.split('-');
  return `${d}/${m}/${a}`;
};

export const formatarDuracao = (ms) => {
  const min = Math.max(0, Math.floor(ms / 60000));
  return `${pad(Math.floor(min / 60))}h${pad(min % 60)}`;
};

export const formatarSaldo = (ms) => {
  const sinal = ms < 0 ? '-' : '+';
  const min = Math.floor(Math.abs(ms) / 60000);
  return `${sinal}${pad(Math.floor(min / 60))}h${pad(min % 60)}`;
};

// Soma pares entrada→saída. Se houver par aberto e for hoje, conta até agora.
export const calcularTrabalhado = (registrosDoDia, agora, ehHoje) => {
  const ord = [...registrosDoDia].sort((a, b) => a.timestamp - b.timestamp);
  let total = 0;
  for (let i = 0; i < ord.length; i += 2) {
    const inicio = ord[i].timestamp;
    const fim = ord[i + 1] ? ord[i + 1].timestamp : ehHoje ? agora.getTime() : null;
    if (fim) total += fim - inicio;
  }
  return total;
};

// Segunda-feira da semana de uma data
export const inicioSemana = (data) => {
  const d = new Date(data.getFullYear(), data.getMonth(), data.getDate());
  d.setDate(d.getDate() - ((d.getDay() + 6) % 7));
  return d;
};
