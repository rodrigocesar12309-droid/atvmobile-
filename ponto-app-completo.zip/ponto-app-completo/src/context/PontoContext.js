import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import * as Location from 'expo-location';
import { useSQLiteContext } from 'expo-sqlite';
import { TIPOS, chaveDia } from '../utils/tempo';
import {
  excluirRegistroDb,
  inserirRegistro,
  limparRegistrosDb,
  listarPorDia,
  listarRegistros,
} from '../database/db';

const INTERVALO_MINIMO_MS = 60 * 1000; // evita batida duplicada

const PontoContext = createContext(null);

export function PontoProvider({ children }) {
  const db = useSQLiteContext();
  const [registros, setRegistros] = useState([]);
  const [agora, setAgora] = useState(new Date());
  const [carregado, setCarregado] = useState(false);

  // Relógio ao vivo
  useEffect(() => {
    const id = setInterval(() => setAgora(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  // Lê tudo do banco e atualiza o estado das telas
  const recarregar = useCallback(async () => {
    setRegistros(await listarRegistros(db));
  }, [db]);

  useEffect(() => {
    recarregar().finally(() => setCarregado(true));
  }, [recarregar]);

  const obterLocalizacao = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return null;
      const pos = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Balanced,
      });
      return { latitude: pos.coords.latitude, longitude: pos.coords.longitude };
    } catch {
      return null;
    }
  };

  const registrarPonto = useCallback(async () => {
    const momento = new Date();
    const dia = chaveDia(momento);
    const hoje = await listarPorDia(db, dia);

    const ultimo = hoje[hoje.length - 1];
    if (ultimo && momento.getTime() - ultimo.timestamp < INTERVALO_MINIMO_MS) {
      return { ok: false, motivo: 'Aguarde 1 minuto entre uma batida e outra.' };
    }

    const local = await obterLocalizacao();
    await inserirRegistro(db, {
      dia,
      timestamp: momento.getTime(),
      tipo: TIPOS[hoje.length % TIPOS.length],
      local,
    });
    await recarregar();
    return { ok: true };
  }, [db, recarregar]);

  const excluirRegistro = async (id) => {
    await excluirRegistroDb(db, id);
    await recarregar();
  };

  const limparTudo = async () => {
    await limparRegistrosDb(db);
    await recarregar();
  };

  return (
    <PontoContext.Provider
      value={{ registros, agora, carregado, registrarPonto, excluirRegistro, limparTudo }}
    >
      {children}
    </PontoContext.Provider>
  );
}

export const usePonto = () => useContext(PontoContext);
