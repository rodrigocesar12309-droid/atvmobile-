import React, { useState } from 'react';
import { Alert, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { usePonto } from '../context/PontoContext';
import { cores } from '../theme';
import {
  TIPOS,
  calcularTrabalhado,
  chaveDia,
  formatarDataLonga,
  formatarDuracao,
  formatarHora,
} from '../utils/tempo';

export default function RegistrarScreen() {
  const { registros, agora, registrarPonto } = usePonto();
  const [salvando, setSalvando] = useState(false);

  const hoje = chaveDia(agora);
  const registrosHoje = registros
    .filter((r) => r.dia === hoje)
    .sort((a, b) => a.timestamp - b.timestamp);
  const proximoTipo = TIPOS[registrosHoje.length % TIPOS.length];
  const trabalhado = calcularTrabalhado(registrosHoje, agora, true);

  const confirmar = () => {
    Alert.alert('Registrar ponto', `${proximoTipo} às ${formatarHora(new Date())}?`, [
      { text: 'Cancelar', style: 'cancel' },
      {
        text: 'Registrar',
        onPress: async () => {
          setSalvando(true);
          const res = await registrarPonto();
          setSalvando(false);
          if (!res.ok) Alert.alert('Não foi possível registrar', res.motivo);
        },
      },
    ]);
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom: 32 }}>
      <View style={styles.topo}>
        <Text style={styles.data}>{formatarDataLonga(agora)}</Text>
        <Text style={styles.relogio}>{formatarHora(agora, true)}</Text>
        <Text style={styles.trabalhado}>Trabalhado hoje: {formatarDuracao(trabalhado)}</Text>
      </View>

      <TouchableOpacity
        style={styles.botao}
        onPress={confirmar}
        disabled={salvando}
        activeOpacity={0.85}
      >
        <Text style={styles.botaoTexto}>
          {salvando ? 'Registrando…' : `Registrar ${proximoTipo.toLowerCase()}`}
        </Text>
      </TouchableOpacity>

      <Text style={styles.titulo}>Batidas de hoje</Text>
      <View style={styles.card}>
        {registrosHoje.length === 0 ? (
          <Text style={styles.vazio}>Nenhuma batida hoje. Toque no botão para começar.</Text>
        ) : (
          registrosHoje.map((r, i) => (
            <View key={r.id} style={[styles.linha, i > 0 && styles.linhaBorda]}>
              <Text style={styles.tipo}>{r.tipo}</Text>
              <Text style={styles.hora}>{formatarHora(new Date(r.timestamp))}</Text>
            </View>
          ))
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: cores.fundo, paddingHorizontal: 20 },
  topo: {
    backgroundColor: cores.primaria,
    borderRadius: 20,
    padding: 24,
    marginTop: 16,
    alignItems: 'center',
  },
  data: { color: '#c9d1e3', fontSize: 15, textTransform: 'capitalize' },
  relogio: {
    color: cores.branco,
    fontSize: 56,
    fontWeight: '700',
    marginVertical: 6,
    fontVariant: ['tabular-nums'],
  },
  trabalhado: { color: cores.destaque, fontSize: 15, fontWeight: '600' },
  botao: {
    backgroundColor: cores.destaque,
    borderRadius: 16,
    paddingVertical: 18,
    alignItems: 'center',
    marginTop: 16,
  },
  botaoTexto: { color: cores.primaria, fontSize: 18, fontWeight: '700' },
  titulo: { fontSize: 18, fontWeight: '700', color: cores.primaria, marginTop: 24, marginBottom: 8 },
  card: { backgroundColor: cores.branco, borderRadius: 14, paddingHorizontal: 14 },
  linha: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 12 },
  linhaBorda: { borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: cores.borda },
  tipo: { fontSize: 15, color: cores.texto },
  hora: { fontSize: 15, fontWeight: '600', color: cores.primaria, fontVariant: ['tabular-nums'] },
  vazio: { color: cores.suave, paddingVertical: 16, textAlign: 'center' },
});
