# Ponto App

Registro de ponto feito com Expo (SDK 58) + React Native, com banco SQLite local.

## Rodar

```bash
npm install
npx expo start -c
```

Escaneie o QR code com o app Expo Go (SDK 58) no Android/iOS.
Se o QR code não conectar: `npx expo start --tunnel`.

## Telas
- Registrar: relógio e botão de batida (Entrada, Saída almoço, Volta almoço, Saída)
- Histórico: dias agrupados, total de horas e saldo (segure uma batida para excluir)
- Resumo: horas da semana e saldo

## Banco de dados
SQLite (`expo-sqlite`), arquivo `ponto.db`. Tabela `registros`:
id, dia, timestamp, tipo, latitude, longitude.
Código em `src/database/db.js`.
