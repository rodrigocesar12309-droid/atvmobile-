// Camada de acesso ao banco SQLite (expo-sqlite)

// Cria a tabela na primeira abertura do app
export async function initDb(db) {
  await db.execAsync(`
    PRAGMA journal_mode = WAL;

    CREATE TABLE IF NOT EXISTS registros (
      id        INTEGER PRIMARY KEY AUTOINCREMENT,
      dia       TEXT    NOT NULL,   -- AAAA-MM-DD
      timestamp INTEGER NOT NULL,   -- milissegundos
      tipo      TEXT    NOT NULL,   -- Entrada, Saída para almoço...
      latitude  REAL,
      longitude REAL
    );

    CREATE INDEX IF NOT EXISTS idx_registros_dia ON registros (dia);
  `);
}

// Converte a linha do banco para o formato usado pelas telas
const paraObjeto = (r) => ({
  id: r.id,
  dia: r.dia,
  timestamp: r.timestamp,
  tipo: r.tipo,
  local:
    r.latitude != null && r.longitude != null
      ? { latitude: r.latitude, longitude: r.longitude }
      : null,
});

export async function listarRegistros(db) {
  const linhas = await db.getAllAsync('SELECT * FROM registros ORDER BY timestamp ASC');
  return linhas.map(paraObjeto);
}

export async function listarPorDia(db, dia) {
  const linhas = await db.getAllAsync(
    'SELECT * FROM registros WHERE dia = ? ORDER BY timestamp ASC',
    [dia]
  );
  return linhas.map(paraObjeto);
}

export async function inserirRegistro(db, { dia, timestamp, tipo, local }) {
  await db.runAsync(
    'INSERT INTO registros (dia, timestamp, tipo, latitude, longitude) VALUES (?, ?, ?, ?, ?)',
    [dia, timestamp, tipo, local?.latitude ?? null, local?.longitude ?? null]
  );
}

export async function excluirRegistroDb(db, id) {
  await db.runAsync('DELETE FROM registros WHERE id = ?', [id]);
}

export async function limparRegistrosDb(db) {
  await db.runAsync('DELETE FROM registros');
}
